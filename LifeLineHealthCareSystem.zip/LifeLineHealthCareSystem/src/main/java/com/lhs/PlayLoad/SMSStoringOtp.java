package com.lhs.PlayLoad;

public class SMSStoringOtp {
	private static int otp;

	public static int getOtp() {
		return otp;
	}

	public static void setOtp(int otp) {
		SMSStoringOtp.otp = otp;
	}

	
}
