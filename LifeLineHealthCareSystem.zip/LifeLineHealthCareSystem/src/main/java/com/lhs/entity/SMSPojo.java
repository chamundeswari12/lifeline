package com.lhs.entity;

public class SMSPojo {
	private String mobileno;

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

}
