package com.lhs.entity;

public enum DoctorAvailablity {
	available,unvailable;

}
